<?php
    
  

    
      $pesquisa=  ($_POST["pesquisa"]);
      $pesquisa= str_replace (" ", "%", $pesquisa);
    // Cria uma variavel com a data e horario atual
    $timestamp= time();
    //Variavel com as chaves de utilização , primeiro a chave privada e logo após a pública.
    $keys="c71f9ecd08d93727b8981273cae85db68713b87f"."eda4700f47a79d099f0673db93e77a32";
    $pubkey= "eda4700f47a79d099f0673db93e77a32";
    //concatenando as variavel de data com a variavel das chaves
    $string=$timestamp.$keys;
    //Generate MD5 digest, also hash is faster than md5 function
    $md5=hash('md5', $string);
    //url para pegar a api  
    $url= "https://gateway.marvel.com:443/v1/public/characters?ts=$timestamp&apikey=$pubkey&hash=$md5&nameStartsWith=$pesquisa";
    // tratando os dados 
    $json = file_get_contents($url);
    $dados = json_decode($json, true );
  
        $quantidade= $dados['data']['results'];
           
        function impressora ( $max, $resultado ){

              $i=0;
              foreach ( $max as $valor ){
              $extension = ".jpg";
              $img = $resultado['data']['results'][$i]['thumbnail']['path']; 
                  
                   echo "
                   <div class=' col-sm-12 col-md-4 col-lg-4 mb-5'>
                       <div class='card text-blue'>
                          <img src='".$img.$extension."' class='card-img-top max-width: 75%; max-height: 75%;'>
                          <div class='card-body'>
                            <h5 class='card-title font-weight-bold'>  ".$resultado['data']['results'][$i]['name']."  </h5>
                           <p class='card-text'> ".$resultado['data']['results'][$i]['description']." </p>
                           </div>
                        </div>
                        </div>";
                        $i++;
                     
                      }  
  }
       



?>
