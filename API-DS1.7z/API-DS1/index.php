
<!doctype html>
<html lang="pt-BR">
<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css" >
    <title>MARVEL</title>
</head>
<?php include "codigo.php"; ?>
<body class="bg-dark">  
    <div class="container">
        
        

                <!--Nav com barra de busca   !-->
                  <nav class="navbar navbar-dark bg-dark">
                    <form class="form-inline col-10" name="formulario" method="post" action="index.php">
                        <input class="form-control mr-md-2 " type="search" placeholder="Personagem" name="pesquisa">
                        <button class="btn btn-outline-danger my-2 my-sm-0" type="submit"> <img src="img/lupita.png" alt="lupa"> </button>
                    </form>
                    <a href="http://marvel.com" class="text-white"> <button class="btn btn-outline-danger my-2 my-sm-0 font-weight-bold" type="submit">MARVEL</button></a>
                </nav>


                <div id="carregando" class="my-3 align-items-center">
               </div>


                <div class="row" >
                
                <!--exibição da busca  !-->
                 <?php 
                  impressora ($quantidade, $dados);
                 ?>
                </div>
        

</div>
   
     
</body>

</html>





